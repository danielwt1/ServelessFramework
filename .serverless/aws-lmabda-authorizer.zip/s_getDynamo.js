
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'danielwt1',
  applicationName: 'aws-lmabda-authorizer',
  appUid: 'xGbK1Rsc61czsMCFJB',
  orgUid: '8a44af7d-9720-4d3d-86da-00b9f5a6deaf',
  deploymentUid: 'e9e67802-7c8c-4d70-8d84-e8822d9e3f2c',
  serviceName: 'aws-lmabda-authorizer',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '7.0.5',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'aws-lmabda-authorizer-dev-getDynamo', timeout: 6 };

try {
  const userHandler = require('./getUserDynamo.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}